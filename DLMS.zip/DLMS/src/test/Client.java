package test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



/**
 * 
 */

/**
 * @author 831375/Sudhish T
 * 
 */
public class Client {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String fileName = FileDemo.fetchFileName("C:\\Users\\gyan computres\\workspace\\DLMS\\WebContent\\notes\\tempUploads\\");
		System.out.println(fileName);
		Demos.move(fileName);
	}

}
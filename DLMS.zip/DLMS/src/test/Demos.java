/**
 * 
 */
package test;



import java.io.IOException;

import org.apache.commons.io.FileUtils;


import sdh.gateway.db.ConnectionDAO;

/**
 * @author sudhi
 *
 */
public class Demos {

	/**
	 * @param args
	 */
	public static void move(String fileName) throws Exception {

		
		System.out.println(FileDemo.moveFile("C:\\Users\\gyan computres\\workspace\\DLMS\\WebContent\\notes\\tempUploads\\"+fileName, "C:\\Users\\gyan computres\\workspace\\DLMS\\WebContent\\notes\\moduleNew.txt"));
	
	}
}

/**
 * 
 */
package test;

import java.net.ServerSocket;

/**
 * @author sudhi
 *
 */
public class StartChats {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			ServerSocket listener = new ServerSocket(9001);
			System.out.println(listener);
//			ChatServer.initiateDiscussionForum(listener);
			ChatServer.closeDiscussionForum(listener);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		

	}

}

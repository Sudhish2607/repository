package test;


import java.awt.Color;
import java.io.File;


import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.entity.StandardEntityCollection;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

class PieChartDemo1 {
	public static void main(String a[])
	{
		getPieChart();
	}

public static void getPieChart() {

	 final DefaultPieDataset data = new DefaultPieDataset();
     data.setValue("Completed Successfully", new Double(1.0));
     data.setValue("Pening Notes", new Double(1.0));

     
     
     
     JFreeChart chart = ChartFactory.createPieChart("My Progress", data, true, true, false);
     try {
         final ChartRenderingInfo info = new 
       ChartRenderingInfo(new StandardEntityCollection()); 
         final File file1 = new File("C:/Users/sudhi/Desktop/Chat/piechart.png");
         ChartUtilities.saveChartAsPNG(file1, chart, 600, 400, info);
     } catch (Exception e) {
//         out.println(e);
     }
     
}
}
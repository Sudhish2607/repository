/**
 * 
 */
package test;

import java.io.File;
import com.oreilly.servlet.MultipartRequest;

import javax.servlet.ServletContext;

/**
 * @author sudhi
 *
 */
public class FileDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String fileName = fetchFileName("C:\\Users\\gyan computres\\workspace\\DLMS\\WebContent\\notes\\tempUploads\\");
//		System.out.println(fileName);
		String fromFile = "C:\\Users\\gyan computres\\workspace\\DLMS\\WebContent\\notes\\tempUploads\\".concat("module.txt");
		System.out.println(moveFile(fromFile, "C:\\Users\\gyan computres\\workspace\\DLMS\\WebContent\\notes\\moduleNew.txt"));
//		fileName.close();
	}

	public static String fetchFileName(String directoryPath) {
		File directory = new File(directoryPath);
		//get all the files from a directory
		File[] fList = directory.listFiles();
		String tempFile = null; 
		for (File file : fList){
		  if (file.isFile()){
			  tempFile = file.getName();
		  }
		}
		return tempFile;
	}
	public static boolean moveFile(String fileWithFromDir, String fileWithToDir) {
		File oldName = new File(fileWithFromDir);
		File newName = new File(fileWithToDir);
		return oldName.renameTo(newName);
	}
}

package test;

import java.net.ServerSocket;

public class StopChats {

	/**
	 * @param args	
	 */
	public static void main(String[] args) {
		try {
			
			ServerSocket listener = new ServerSocket();
			System.out.println(listener);
//			ChatServer.initiateDiscussionForum(listener);
			ChatServer.closeDiscussionForum(listener);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

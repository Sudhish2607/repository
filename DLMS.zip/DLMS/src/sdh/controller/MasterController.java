package sdh.controller;

import java.io.IOException;
import java.net.ServerSocket;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sdh.bean.Faculty;
import sdh.bean.ModuleNotes;
import sdh.bean.Subject;
import sdh.bean.UserDetails;
import sdh.gateway.db.ConnectionDAO;
import sdh.gateway.pipeline.DiscussionForumServer;
import sdh.gateway.pipeline.Participants;

/**
 * MasterController.java
 * 
 * Version:
 * 		 v1.1, 07/17/2017, 10:20:18
 *
 * Revision:
 *		Initial revision 
 */

/**
 * This program acts as a master controller for all the functionality of the website.
 * 
 * @author Thazhakasseril, Sudhish Surendran
 *
 */

public class MasterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Given the request and response from the front end, this function
	 * handles the Get method of the website.
	 *
	 * @param		request		request send by the application
	 * @param		response	response send by the application
	 * 
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	/**
	 * Given the request and response from the front end, this function
	 * handles the Post method of the website.
	 *
	 * @param		request		request send by the application
	 * @param		response	response send by the application
	 * 
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");						// action value depicts the type of front end functionality 
		System.out.println(action);
		
		//	functionality if any new user is being added
		if (action.equals("addProfOrStudentOrAdmin")) {
			
			// setting the user details to be entered in DB.
			UserDetails newUser = new UserDetails();
			newUser.setUserId(ConnectionDAO.getUserId(request
					.getParameter("typeId")));
			newUser.setTypeId(request.getParameter("typeId"));
			newUser.setUserName(request.getParameter("userName"));
			newUser.setTitle(request.getParameter("title"));
			newUser.setFirstName(request.getParameter("firstName"));
			newUser.setLastName(request.getParameter("lastName"));
			newUser.setEmail(request.getParameter("email"));
			try {
				newUser.setPassword(sdh.algorithm.aes.AESalgorithm
						.encrypt(request.getParameter("password")));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String dob = (request.getParameter("days") + "-"
					+ request.getParameter("month") + "-" + request
					.getParameter("year"));

			SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
			try {
				java.util.Date parsed = format.parse(dob);
				java.sql.Date sql = new java.sql.Date(parsed.getTime());
				newUser.setDob(sql);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			newUser.setAddress(request.getParameter("address"));
			String changedDate = null;
			java.util.Date d = new java.util.Date();
			changedDate = new SimpleDateFormat("dd-MMM-yyyy").format(d);
			java.sql.Date dS = new java.sql.Date(123);
			dS.setDate(d.getDate());
			dS.setMonth(d.getMonth());
			dS.setYear(d.getYear());
			newUser.setRegisteredTime(dS);
			newUser.setSecretQuestion(request.getParameter("secretQuestion"));
			newUser.setSecretAnswer(request.getParameter("secretAnswer"));
			newUser.setContactNo(request.getParameter("contactNo"));
			
			// add newuser data into DB
			boolean status = ConnectionDAO.addNewUser(newUser);
			
			System.out.println("in COntroller::::" + status);
			String statusURLpath = "";
			
			// setting session parameter for user login
			if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Admin"))
				statusURLpath = "admin";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Professor"))
				statusURLpath = "professor";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Student"))
				statusURLpath = "student";
			
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath + "/Status.jsp?id="
							+ newUser.getUserId() + "&msg=added&status="
							+ status + "&errorMsg=Internel%20Server%20Error");
			
			dispatcher.include(request, response);

		}
		
		//		functionality if any new Syllabus is being added
		else if (action.equals("addSyllabus")) {
			
			// creating bean class for Subject with subject parameters
			Subject subject = new Subject();
			subject.setSubjectId(Integer.parseInt(request
					.getParameter("subjectId")));
			subject.setSubject(request.getParameter("subjectName")
					.toUpperCase());
			subject.setModule(request.getParameter("moduleName"));
			subject.setModuleId(ConnectionDAO.getModuleId(subject.getSubject(),
					subject.getSubjectId()));

			// adding syllabus data in the DB
			boolean status = ConnectionDAO.addSyllabus(subject);
			
			System.out.println("in COntroller::::" + status);
			
			// setting session value for user login
			String statusURLpath = "";
			if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Admin"))
				statusURLpath = "admin";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Professor"))
				statusURLpath = "professor";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Student"))
				statusURLpath = "student";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath + "/Status.jsp?id="
							+ subject.getModuleId() + "&msg=added&status="
							+ status + "&errorMsg=Internel%20Server%20Error");
			dispatcher.include(request, response);

		}
		
		// functionality if any existing user details is getting updated
		else if (action.equals("updateUserDetails")) {
			
			// creating bean class for user update
			UserDetails updatedUserDetails = new UserDetails();
			updatedUserDetails.setUserId(request.getParameter("userId"));
			updatedUserDetails.setUserName(request.getParameter("userName"));
			updatedUserDetails.setTitle(request.getParameter("title"));
			updatedUserDetails.setFirstName(request.getParameter("firstName"));
			updatedUserDetails.setLastName(request.getParameter("lastName"));
			updatedUserDetails.setEmail(request.getParameter("email"));
			updatedUserDetails.setAddress(request.getParameter("address"));
			updatedUserDetails.setContactNo(request.getParameter("contactNo"));
			
			// updating the user details in DB
			boolean status = ConnectionDAO.updateUser(updatedUserDetails);
			System.out.println("in COntroller::::" + status);

			// setting session value for user login
			String statusURLpath = "";
			if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Admin"))
				statusURLpath = "admin";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Professor"))
				statusURLpath = "professor";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Student"))
				statusURLpath = "student";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath + "/Status.jsp?id="
							+ updatedUserDetails.getUserId()
							+ "&msg=updated&status=" + status
							+ "&errorMsg=Internel%20Server%20Error");
			dispatcher.include(request, response);

		}
		
		// functionality if any update in existing syllabus
		else if (action.equals("updateSyllabus")) {
			
			// creating bean class for syllabus
			Subject updatedSubject = new Subject();
			updatedSubject.setModuleId(request.getParameter("moduleId"));
			updatedSubject.setSubjectId(Integer.parseInt(request
					.getParameter("subjectId")));
			updatedSubject.setModule(request.getParameter("module"));
			updatedSubject.setSubject(request.getParameter("subject"));
			
			// updating DB with new value
			boolean status = ConnectionDAO.updateSubject(updatedSubject);
			System.out.println("in COntroller::::" + status);

			// setting session value for user login
			String statusURLpath = "";
			if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Admin"))
				statusURLpath = "admin";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Professor"))
				statusURLpath = "professor";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Student"))
				statusURLpath = "student";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath + "/Status.jsp?id="
							+ updatedSubject.getModuleId()
							+ "&msg=updated&status=" + status
							+ "&errorMsg=Internel%20Server%20Error");
			dispatcher.include(request, response);

		}
		
		// functionality if any faculty is being alloted to any subject
		else if (action.equals("assignFaculty")) {
			
			// creating bean class for faculty
			Faculty assignFaculty = new Faculty();
			assignFaculty.setProfId(request.getParameter("userId"));
			assignFaculty.setProfessorName(ConnectionDAO
					.getProfessorName(assignFaculty.getProfId()));
			assignFaculty.setSubjectId(ConnectionDAO.getSubjectId(request
					.getParameter("subject")));
			
			// updating faculty and subject details in DB
			boolean status = ConnectionDAO
					.assignFacultyToSubject(assignFaculty);
			System.out.println("in COntroller::::" + status);

			// setting session value for user login
			String statusURLpath = "";
			if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Admin"))
				statusURLpath = "admin";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Professor"))
				statusURLpath = "professor";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Student"))
				statusURLpath = "student";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath
							+ "/Status.jsp?id="
							+ assignFaculty.getProfId()
							+ "&msg=assigned&status="
							+ status
							+ "&errorMsg=A%20Professor%20can%20only%20teach%20one%20Subject");
			dispatcher.include(request, response);

		}
		
		// functionality if any faculty details is to be updated
		else if (action.equals("updateFaculty")) {
			
			// creating faculty bean class
			Faculty assignFaculty = new Faculty();
			assignFaculty.setProfId(request.getParameter("userId"));
			assignFaculty.setSubjectId(ConnectionDAO.getSubjectId(request
					.getParameter("subject")));
			
			// adding faculty details in DB
			boolean status = ConnectionDAO
					.updateAssignFacultyToSubject(assignFaculty);
			System.out.println("in COntroller::::" + status);

			// setting session value for user login
			String statusURLpath = "";
			if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Admin"))
				statusURLpath = "admin";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Professor"))
				statusURLpath = "professor";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Student"))
				statusURLpath = "student";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath
							+ "/Status.jsp?id="
							+ assignFaculty.getProfId()
							+ "&msg=updated&status="
							+ status
							+ "&errorMsg=A%20Professor%20can%20only%20teach%20one%20Subject");
			dispatcher.include(request, response);
		}
		
		// functionality if any existing faculty is to be deleted
		else if (action.equals("deleteFaculty")) {
			
			// remove faculty details from DB
			boolean status = ConnectionDAO.deleteAssignFacultyToSubject(request
					.getParameter("userId"));
			System.out.println("in COntroller::::" + status);

			String statusURLpath = "";
			if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Admin"))
				statusURLpath = "admin";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Professor"))
				statusURLpath = "professor";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Student"))
				statusURLpath = "student";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath + "/Status.jsp?id="
							+ request.getParameter("userId")
							+ "&msg=deleted&status=" + status
							+ "&errorMsg=Internel%20Server%20Error");
			dispatcher.include(request, response);
		}
		
		// functionality for user login
		else if ("login".equals(action)) {
			String userName = request.getParameter("userName");
			String password = request.getParameter("password");
			UserDetails userLoginCred = new UserDetails();
			userLoginCred.setUserName(userName);
			userLoginCred.setPassword(password);
			String[] roleName = new String[3];
			roleName = ConnectionDAO.validateUser(userLoginCred);
			String tempRole = roleName[0];
			String role = "";
			String name = null;
			if (!("error".equals(tempRole))) {
				name = roleName[1];
				role = tempRole;
			}
			HttpSession session = request.getSession();

			if (!("error".equals(tempRole))) {
				session.setAttribute("id", roleName[2]);
				session.setAttribute("name", name);
				session.setAttribute("role", role);

				if (role.equalsIgnoreCase("Admin")) {
					response.sendRedirect("admin/index.jsp");
				} else if (role.equalsIgnoreCase("Professor")) {
					response.sendRedirect("professor/index.jsp");
				} else {
					response.sendRedirect("student/index.jsp");
				}
			} else {
				response.setContentType("text/html");
				response.getWriter()
						.write("<html>"
								+ "<head>"
								+ "<script>"
								+ "alert(\"Invalid username or password\"); window.location=\"index.jsp\";"
								+ "</script>");
				response.getWriter().write("</head>" + "<body>");
				response.getWriter().write("</body>");
				response.getWriter().write("</html>");
				response.getWriter().close();
			}
		}
		
		// functionality for user logout
		else if ("logout".equals(action)) {
			HttpSession session = request.getSession(false);

			if (session != null) {
				session.removeAttribute("name");
				session.removeAttribute("id");
				session.removeAttribute("role");
				session.invalidate();

				response.setContentType("text/html");
				response.getWriter()
						.write("<html>"
								+ "<head>"
								+ "<script>"
								+ "alert(\"You have successfully logged out!\"); window.location=\"index.jsp\";"
								+ "</script>");
				response.getWriter().write("</head>" + "<body>");
				response.getWriter().write("</body>");
				response.getWriter().write("</html>");
				response.getWriter().close();
			}
		}
		
		// functionality for adding any notes
		else if ("addNotes".equals(action)) {

			ModuleNotes notes = new ModuleNotes();
			notes.setNotesId(ConnectionDAO.generateQuestionId());
			notes.setModuleId(ConnectionDAO.getModuleIdFor(
					request.getParameter("subject"),
					request.getParameter("module")));
			notes.setProfId(request.getSession(false).getAttribute("id")
					.toString());
			notes.setNotesFileName(notes.getModuleId() + ".pdf");

			boolean status = ConnectionDAO.addNotes(notes);
			System.out.println("in COntroller::::" + status);

			String statusURLpath = "professor";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath
							+ "/addNotesUpload.jsp?notesId="
							+ notes.getNotesId() + "&moduleId="
							+ notes.getModuleId());
			dispatcher.include(request, response);

		}
		
		// functionality for chatting with students and faculty
		else if ("initiateDiscussionForum".equals(action)) {
			String[] participants = request.getParameterValues("participants");
			String idOfInitiator = request.getSession(false).getAttribute("id")
					.toString();
			ConnectionDAO.resetDiscussionForum();
			ConnectionDAO.initiateDiscussionForum(idOfInitiator);
			for (int i = 0; i < participants.length; i++) {
				ConnectionDAO.initiateDiscussionForum(participants[i]);
			}

			response.setContentType("text/html");
			response.getWriter()
					.write("<html>"
							+ "<head>"
							+ "<script>"
							+ "alert(\"You have successfully added participants for Discussion Forum\"); window.location=\"professor/index.jsp\";"
							+ "</script>");
			response.getWriter().write("</head>" + "<body>");
			try {
				ServerSocket listener = new ServerSocket(9001);
				System.out.println(listener);
				DiscussionForumServer.initiateDiscussionForum(listener);
				// ChatServer.closeDiscussionForum(listener);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.getWriter().write("</body>");
			response.getWriter().write("</html>");
			response.getWriter().close();

		}
		
		// functionality for deleting the discussion forum/ chat function
		else if ("deleteDiscussionForum".equals(action)) {

			ConnectionDAO.resetDiscussionForum();

			response.setContentType("text/html");
			response.getWriter()
					.write("<html>"
							+ "<head>"
							+ "<script>"
							+ "alert(\"You have successfully deleted the existing Discussion Forum\"); window.location=\"professor/index.jsp\";"
							+ "</script>");
			response.getWriter().write("</head>" + "<body>");

			response.getWriter().write("</body>");
			response.getWriter().write("</html>");
			response.getWriter().close();

		}
		
		// functionality for initiating discussion forum
		else if ("enterDiscussionForum".equals(action)) {
			// ServletConfig config = getServletConfig();
			ServletContext config = getServletContext();
			String serverIP = config.getInitParameter("server-ip");
			if ((request.getSession(false).getAttribute("id").toString())
					.equals(ConnectionDAO.isParticipant(request
							.getSession(false).getAttribute("id").toString()))) {
				try {
					Participants.addParticipant(serverIP,
							request.getSession(false).getAttribute("id")
									.toString());

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String statusURLpath = "";
				if (request.getSession(false).getAttribute("role").toString()
						.equalsIgnoreCase("Admin"))
					statusURLpath = "admin";
				else if (request.getSession(false).getAttribute("role")
						.toString().equalsIgnoreCase("Professor"))
					statusURLpath = "professor";
				else if (request.getSession(false).getAttribute("role")
						.toString().equalsIgnoreCase("Student"))
					statusURLpath = "student";
				RequestDispatcher dispatcher = request
						.getRequestDispatcher(statusURLpath + "/index.jsp");
				dispatcher.include(request, response);
			} else {
				response.setContentType("text/html");
				response.getWriter()
						.write("<html>"
								+ "<head>"
								+ "<script>"
								+ "alert(\"You have not been added as a participant.\"); window.location=\"student/index.jsp\";"
								+ "</script>");
				response.getWriter().write("</head>" + "<body>");

				response.getWriter().write("</body>");
				response.getWriter().write("</html>");
				response.getWriter().close();
			}
		} else if ("addProgress".equals(action)) {
			String moduleNotes = request.getParameter("moduleNotes").toString();

			ConnectionDAO.addProgress(
					request.getSession(false).getAttribute("id").toString(),
					moduleNotes.substring(0, moduleNotes.length() - 4));

			response.setContentType("text/html");
			response.getWriter()
					.write("<html>"
							+ "<head>"
							+ "<script>"
							+ "alert(\"You have completed this module.\"); window.location=\"student/viewNotes.jsp\";"
							+ "</script>");
			response.getWriter().write("</head>" + "<body>");

			response.getWriter().write("</body>");
			response.getWriter().write("</html>");
			response.getWriter().close();

		}
		
		
		// functionality for adding news by faculty
		if (action.equals("addNews")) {
			String newsId = ConnectionDAO.getNewsId();
			boolean status = ConnectionDAO.addNews(newsId,
					request.getSession(false).getAttribute("id").toString(),
					request.getParameter("news"));
			String statusURLpath = "";
			if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Admin"))
				statusURLpath = "admin";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Professor"))
				statusURLpath = "professor";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Student"))
				statusURLpath = "student";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath + "/Status.jsp?id="
							+ newsId + "&msg=added&status=" + status
							+ "&errorMsg=Internel%20Server%20Error");
			dispatcher.include(request, response);

		}

		// functionality for updating news
		if (action.equals("updateNews")) {
			String newsId = request.getParameter("newsId");
			boolean status = ConnectionDAO.updateNews(newsId,
					request.getParameter("news"));
			String statusURLpath = "";
			if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Admin"))
				statusURLpath = "admin";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Professor"))
				statusURLpath = "professor";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Student"))
				statusURLpath = "student";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath + "/Status.jsp?id="
							+ newsId + "&msg=updateded&status=" + status
							+ "&errorMsg=Internel%20Server%20Error");
			dispatcher.include(request, response);

		}
		
		// functionality for deleting user
		if (action.equals("deleteUser")) {
			String actionId = request.getParameter("typeId");
			String userId = "";
			if (("ADSD".equals(actionId)) || ("PRSD".equals(actionId))
					|| ("STSD".equals(actionId))) {
				userId = request.getParameter("userId");
				System.out.println(userId);
				boolean status = false;
				try {
					status = ConnectionDAO.deleteUser(userId);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(status);

			} else if ("News".equals(actionId)) {
				String news = request.getParameter("news");
				;
				try {
					userId = ConnectionDAO.deleteNews(news);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				response.setContentType("text/html");

				if (request.getSession(false).getAttribute("role").toString()
						.equalsIgnoreCase("Admin"))
					response.getWriter()
							.write("<html>"
									+ "<head>"
									+ "<script>"
									+ "alert(\"You have deleted the selected news feed.\"); window.location=\"admin/index.jsp\";"
									+ "</script>");
				else if (request.getSession(false).getAttribute("role")
						.toString().equalsIgnoreCase("Professor"))
					response.getWriter()
							.write("<html>"
									+ "<head>"
									+ "<script>"
									+ "alert(\"You have deleted the selected news feed.\"); window.location=\"professor/index.jsp\";"
									+ "</script>");
				response.getWriter().write("</head>" + "<body>");
				response.getWriter().write("</body>");
				response.getWriter().write("</html>");
				response.getWriter().close();

			} else if ("Syllabus".equals(actionId)) {
				String module = request.getParameter("syllabus");
				;
				try {
					userId = ConnectionDAO.deleteModule(module);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			String statusURLpath = "";
			if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Admin"))
				statusURLpath = "admin";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Professor"))
				statusURLpath = "professor";
			else if (request.getSession(false).getAttribute("role").toString()
					.equalsIgnoreCase("Student"))
				statusURLpath = "student";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(statusURLpath
							+ "/Status.jsp?id="
							+ userId
							+ "&msg=deleteded&status=true&errorMsg=Internel%20Server%20Error");
			dispatcher.include(request, response);

		} else {
			response.getWriter().println("error");
		}
	}

}

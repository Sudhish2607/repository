package sdh.gateway.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 * ConnectionEstablisher.java
 * 
 * Version:
 * 		 v1.1, 07/16/2017, 18:01:18
 *
 * Revision:
 *		Initial revision 
 */

/**
 * This program acts as an interface for connecting to Database.
 * 
 * @author Thazhakasseril, Sudhish Surendran
 *
 */

public class ConnectionEstablisher {
	
	
	/**
	 * This function establishes a conneciton with DataBase
	 *
	 * @return					Connection with DB
	 */
	public static Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String host = "169.254.84.13";
		String port = "1521";
		String SID = "XE";
		String url = "jdbc:oracle:thin:@" + host + ":" + port + ":" + SID;
		System.out.println("info " + new Date() + " Entering DB with URL::"
				+ url);

		String username = "MCAPROJECT";
		String password = "sudhish";
		System.out.println("info " + new Date() + " Entering DB with USER::"
				+ username);
		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return connection;
	}

	
	/**
	 * This function closes the provided connection
	 *
	 * @param		connection		connection to be closed
	 */
	public static void closeConnection(Connection connection) {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	/**
	 * This function closes the provided result set
	 *
	 * @param		result		result set to be closed
	 */
	public static void closeResultSet(ResultSet result) {
		if (result != null) {
			try {
				result.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	
	/**
	 * This function closes the provided prepared statement
	 *
	 * @param		preStmt		prepared statement to be closed
	 */
	public static void closePreparedStatement(PreparedStatement preStmt) {
		if (preStmt != null) {
			try {
				preStmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}

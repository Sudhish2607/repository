package sdh.gateway.db;

/**
 * Procedure.java
 * 
 * Version:
 * 		 v1.1, 07/16/2017, 18:01:18
 *
 * Revision:
 *		Initial revision 
 */

/**
 * This program used for providing Procedures for DB updation and deletion.
 * 
 * @author Thazhakasseril, Sudhish Surendran
 *
 */

import java.sql.*;

import oracle.jdbc.pool.OracleDataSource;
import oracle.jdbc.*;

public class Procedure {
	public static void main(String args[]) throws SQLException {
//		enableConstraint();
		disableConstraint();
	}
	
	public static void enableConstraint() throws SQLException {
		
		enable("MCAPROJECT","USER_DETAILS");
		enable("MCAPROJECT","USER_TYPE");
		enable("MCAPROJECT","NEWS_FEEDS");
		enable("MCAPROJECT","SUBJECT");
		enable("MCAPROJECT","STUDENT_PROGRESS");
		enable("MCAPROJECT","MODULE_NOTES");
		enable("MCAPROJECT","FACULTY");
		
	}
	public static void disableConstraint() throws SQLException {
		
	disable("MCAPROJECT","FACULTY");
	disable("MCAPROJECT","MODULE_NOTES");
	disable("MCAPROJECT","STUDENT_PROGRESS");
	disable("MCAPROJECT","SUBJECT");
	disable("MCAPROJECT","NEWS_FEEDS");
	disable("MCAPROJECT","USER_TYPE");
	disable("MCAPROJECT","USER_DETAILS");
	}
	
	private static void enable(String owner, String table) throws SQLException {

		// connect to a local XE database as user HR
		OracleDataSource ods = new OracleDataSource();
		
		String host = "169.254.84.13";
		String port = "1521";
		String SID = "XE";
		String username = "MCAPROJECT";
		String password = "sudhish";

		String url = "jdbc:oracle:thin:"+username+"/"+password+"@" + host + ":" + port + "/" + SID;
		
		ods.setURL(url);
		Connection conn = ods.getConnection();

		String jobquery = "begin 	for cur in (select owner, constraint_name , table_name 	from all_constraints		where owner = '"+owner+"' and		TABLE_NAME = '"+table+"') loop	  execute immediate 'ALTER TABLE '||cur.owner||'.'||cur.table_name||'	  MODIFY CONSTRAINT \"'||cur.constraint_name||'\" ENABLE ';   end loop; end;";
		CallableStatement callStmt = conn.prepareCall(jobquery);

		callStmt.execute();

		/*// return the result set
		ResultSet rset = (ResultSet) callStmt.getObject(1);

		// determine the number of columns in each row of the result set
		ResultSetMetaData rsetMeta = rset.getMetaData();
		int count = rsetMeta.getColumnCount();

		// print the results, all the columns in each row
		while (rset.next()) {
			String rsetRow = "";
			for (int i = 1; i <= count; i++) {
				rsetRow = rsetRow + " " + rset.getString(i);
			}
			System.out.println(rsetRow);
		}*/
		conn.commit();
		conn.close();
	}
	
	private static void disable(String owner, String table) throws SQLException {

		// connect to a local XE database as user HR
		OracleDataSource ods = new OracleDataSource();
		
		String host = "169.254.84.13";
		String port = "1521";
		String SID = "XE";
		String username = "MCAPROJECT";
		String password = "sudhish";

		String url = "jdbc:oracle:thin:"+username+"/"+password+"@" + host + ":" + port + "/" + SID;
		
		ods.setURL(url);
		Connection conn = ods.getConnection();

		String jobquery = "begin 	for cur in (select owner, constraint_name , table_name 	from all_constraints		where owner = '"+owner+"' and		TABLE_NAME = '"+table+"') loop	  execute immediate 'ALTER TABLE '||cur.owner||'.'||cur.table_name||'	  MODIFY CONSTRAINT \"'||cur.constraint_name||'\" DISABLE ';   end loop; end;";
		CallableStatement callStmt = conn.prepareCall(jobquery);

		callStmt.execute();

		/*// return the result set
		ResultSet rset = (ResultSet) callStmt.getObject(1);

		// determine the number of columns in each row of the result set
		ResultSetMetaData rsetMeta = rset.getMetaData();
		int count = rsetMeta.getColumnCount();

		// print the results, all the columns in each row
		while (rset.next()) {
			String rsetRow = "";
			for (int i = 1; i <= count; i++) {
				rsetRow = rsetRow + " " + rset.getString(i);
			}
			System.out.println(rsetRow);
		}*/
		conn.commit();
		conn.close();
	}
	
}

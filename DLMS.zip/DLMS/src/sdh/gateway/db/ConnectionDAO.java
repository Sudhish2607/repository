package sdh.gateway.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import sdh.algorithm.aes.AESalgorithm;
import sdh.bean.Faculty;
import sdh.bean.ModuleNotes;
import sdh.bean.Subject;
import sdh.bean.UserDetails;


/**
 * ConnectionDAO.java
 * 
 * Version:
 * 		 v1.1, 07/16/2017, 18:01:18
 *
 * Revision:
 *		Initial revision 
 */

/**
 * This program acts as a query generator for interacting with Database.
 * 
 * @author Thazhakasseril, Sudhish Surendran
 *
 */

public class ConnectionDAO {
	
	
	
	public static Connection conCore = null;				// holds Oracle connection
	public static PreparedStatement preStmt = null;			// holds query to be executed in DB
	public static ResultSet result = null;					// holds result of the query
	
	
	/**
	 * This function is used to get news for the side bar navigation
	 * 
	 * @return					Side bar data fetched from DB
	 */
	public static ArrayList<ArrayList<String>> getSidebarData() {

		ArrayList<ArrayList<String>> sidebarData = new ArrayList<ArrayList<String>>();
		ArrayList<String> sidebarRow = null;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT * From MCAPROJECT.SUBJECT order by SUBJECT";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				while (result.next()) {
					sidebarRow = new ArrayList<String>();
					sidebarRow.add(result.getString(3));
					sidebarRow.add(result.getString(4));
					sidebarData.add(sidebarRow);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarData;
	}
	public static ArrayList<ArrayList<String>> fetchAllNotesPublishedByUser(String userId) {

		ArrayList<ArrayList<String>> sidebarData = new ArrayList<ArrayList<String>>();
		ArrayList<String> sidebarRow = null;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select nts.notes_id, sub.module_id, sub.subject, sub.module from subject sub inner join module_notes nts on sub.module_id=nts.module_id where nts.prof_id='"+userId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				while (result.next()) {
					sidebarRow = new ArrayList<String>();
					sidebarRow.add(result.getString(1));
					sidebarRow.add(result.getString(2));
					sidebarRow.add(result.getString(3));
					sidebarRow.add(result.getString(4));
					sidebarData.add(sidebarRow);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarData;
	}
	public static ArrayList<String> getSubjectAssignedToProfessor(String userId) {

		ArrayList<String> sidebarData = new ArrayList<String>();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select distinct(f.subject_id), s.subject from faculty f inner join subject s on f.subject_id=s.subject_id where f.prof_id ='" + userId + "'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				while (result.next()) {
					
					sidebarData.add(result.getString(1));
					sidebarData.add(result.getString(2));
					
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarData;
	}
	
	public static ArrayList<String> fetchAllModules(String subject, String profId) {

		ArrayList<String> sidebarData = new ArrayList<String>();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select module from subject where subject ='" + subject + "' and module_id not in (select module_id from module_notes where prof_id='" + profId + "')";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				while (result.next()) {
					
					sidebarData.add(result.getString(1));
									
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarData;
	}
	
	public static ArrayList<String> fetchAllPreExistingModulesNotes(String subject, String profId) {

		ArrayList<String> sidebarData = new ArrayList<String>();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select module from subject where subject ='" + subject + "' and module_id in (select module_id from module_notes where prof_id='" + profId + "')";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				while (result.next()) {
					
					sidebarData.add(result.getString(1));
									
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarData;
	}
	
	
	
	public static ArrayList<ArrayList<String>> getUserDetails(String type) {

		ArrayList<ArrayList<String>> userDetails = new ArrayList<ArrayList<String>>();
		ArrayList<String> sidebarRow = null;
		String typeId=null;
		conCore = ConnectionEstablisher.getConnection();
try {
if(type.equals("Admin"))
	typeId = "ADSD";
else if(type.equals("Professor"))
	typeId = "PRSD"; 
else if(type.equals("Student"))
	typeId = "STSD";
else if(type.equals("NewsFeed")){
	return getNewsFeedData();
}
else if(type.equals("Syllabus")){
	return getSyllabusData();
}
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select USER_ID,USER_NAME,TITLE,FIRST_NAME,LAST_NAME,EMAIL,DOB,ADDRESS,REGISTERED_TIME,CONTACTNO from MCAPROJECT.USER_DETAILS where type_id='" + typeId + "'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				sidebarRow = new ArrayList<String>();
				sidebarRow.add("USER_ID");
				sidebarRow.add("USER_NAME");
				sidebarRow.add("TITLE");
				sidebarRow.add("FIRST_NAME");
				sidebarRow.add("LAST_NAME");
				sidebarRow.add("CONTACTNO");
				sidebarRow.add("EMAIL");
				sidebarRow.add("DOB");
				sidebarRow.add("ADDRESS");
				sidebarRow.add("REGISTERED_TIME");
				userDetails.add(sidebarRow);
				
				while (result.next()) {
					sidebarRow = new ArrayList<String>();
					sidebarRow.add(result.getString(1));
					sidebarRow.add(result.getString(2));
					sidebarRow.add(result.getString(3));
					sidebarRow.add(result.getString(4));
					sidebarRow.add(result.getString(5));
					sidebarRow.add(result.getString(10));
					sidebarRow.add(result.getString(6));
					sidebarRow.add(result.getString(7));
					sidebarRow.add(result.getString(8));
					sidebarRow.add(result.getString(9));
					userDetails.add(sidebarRow);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return userDetails;
	}
	
	
	
	
	
	private static ArrayList<ArrayList<String>> getSyllabusData() {
		ArrayList<ArrayList<String>> sidebarSubModCount = new ArrayList<ArrayList<String>>();
		ArrayList<String> sidebarRow = null;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT s.subject_id, s.module_id, s.subject, s.module, d.user_name, d.title, d.first_name, d.last_name, d.email, d.contactno FROM subject s LEFT JOIN faculty f ON s.SUBJECT_ID=f.SUBJECT_ID LEFT JOIN user_details d ON f.PROF_ID=d.USER_ID";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				sidebarRow = new ArrayList<String>();
				sidebarRow.add("Subject ID");
				sidebarRow.add("Module ID");
				sidebarRow.add("Subject");
				sidebarRow.add("Module");
				sidebarRow.add("Name of Faculty");
				sidebarRow.add("Email ID");
				sidebarRow.add("Contact No");
				sidebarSubModCount.add(sidebarRow);
				
				while (result.next()) {
					sidebarRow = new ArrayList<String>();
					sidebarRow.add(result.getLong(1)+"");
					sidebarRow.add(result.getString(2));
					sidebarRow.add(result.getString(3));
					sidebarRow.add(result.getString(4));
					if(result.getString(5)!=null) {
						sidebarRow.add(result.getString(5)+" ("+result.getString(6)+" "+result.getString(7)+" "+result.getString(8)+")");
						sidebarRow.add(result.getString(9));
						sidebarRow.add(result.getString(10));
					} else {
						sidebarRow.add("-");
						sidebarRow.add("-");
						sidebarRow.add("-");
					}
					sidebarSubModCount.add(sidebarRow);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarSubModCount;
	}


	public static ArrayList<String> fetchUserDetails(String userId) {
		ArrayList<String> sidebarRow = new ArrayList<String>();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select user_name, title, first_name, last_name, email, address, contactno from user_details where user_id ='"+userId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				
				while (result.next()) {
					sidebarRow.add(result.getString(1));
					sidebarRow.add(result.getString(2));
					sidebarRow.add(result.getString(3));
					sidebarRow.add(result.getString(4));
					sidebarRow.add(result.getString(5));
					sidebarRow.add(result.getString(6));
					sidebarRow.add(result.getString(7));
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarRow;
	}
	
	
	public static ArrayList<String> fetchAllUserId(String typeId) {
		ArrayList<String> sidebarRow = new ArrayList<String>();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select user_id from user_details where type_id='"+typeId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				
				while (result.next()) {
					sidebarRow.add(result.getString(1));
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarRow;
	}
	
	public static ArrayList<String> fetchAllSubjects() {
		ArrayList<String> sidebarRow = new ArrayList<String>();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select unique(subject) from subject";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				
				while (result.next()) {
					sidebarRow.add(result.getString(1));
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarRow;
	}
	
	public static ArrayList<String> fetchModuleDetails(String moduleId) {
		ArrayList<String> sidebarRow = new ArrayList<String>();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select subject_id, subject, module from subject where module_id='"+moduleId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				
				while (result.next()) {
					sidebarRow.add(result.getString(1));
					sidebarRow.add(result.getString(2));
					sidebarRow.add(result.getString(3));
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarRow;
		
	}	
		
	public static ArrayList<String> fetchAllModuleId() {
		ArrayList<String> sidebarRow = new ArrayList<String>();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select module_id from subject order by module_id";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				
				while (result.next()) {
					sidebarRow.add(result.getString(1));
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarRow;
	}
	
	
	private static ArrayList<ArrayList<String>> getNewsFeedData() {
		ArrayList<ArrayList<String>> sidebarSubModCount = new ArrayList<ArrayList<String>>();
		ArrayList<String> sidebarRow = null;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT d.user_name, d.title, d.first_name, d.last_name, n.news, d.email, d.CONTACTNO FROM user_details d INNER JOIN news_feeds n ON d.user_id=n.prof_id";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				sidebarRow = new ArrayList<String>();
				sidebarRow.add("Posted by");
				sidebarRow.add("NEWS");
				sidebarRow.add("Email ID of poster");
				sidebarRow.add("Contact No");
				sidebarSubModCount.add(sidebarRow);
				
				while (result.next()) {
					sidebarRow = new ArrayList<String>();
					sidebarRow.add(result.getString(1)+" ("+result.getString(2)+" "+result.getString(3)+" "+result.getString(4)+")");
					sidebarRow.add(result.getString(5));
					sidebarRow.add(result.getString(6));
					sidebarRow.add(result.getString(7));
					sidebarSubModCount.add(sidebarRow);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarSubModCount;
	}
	
	public static ArrayList<ArrayList<String>> getNewsFeedSideBarData() {
		ArrayList<ArrayList<String>> sidebarSubModCount = new ArrayList<ArrayList<String>>();
		ArrayList<String> sidebarRow = null;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT d.user_name, n.news FROM user_details d INNER JOIN news_feeds n ON d.user_id=n.prof_id";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				while (result.next()) {
					sidebarRow = new ArrayList<String>();
					sidebarRow.add(result.getString(1));
					sidebarRow.add(result.getString(2));
					sidebarSubModCount.add(sidebarRow);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarSubModCount;
	}


	public static ArrayList<ArrayList<String>> getSidebarSubModCount() {

		ArrayList<ArrayList<String>> sidebarSubModCount = new ArrayList<ArrayList<String>>();
		ArrayList<String> sidebarRow = null;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT s.subject, count(*) FROM MCAPROJECT.SUBJECT s group by s.SUBJECT order by s.SUBJECT";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				while (result.next()) {
					sidebarRow = new ArrayList<String>();
					sidebarRow.add(result.getString(1));
					sidebarRow.add(result.getInt(2)+"");
					sidebarSubModCount.add(sidebarRow);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarSubModCount;
	}
	
	public static String getUserId(String typeId) {

		String userId = new String();
		String part1=null;
		int count=0;
		if(typeId.equals("ADSD"))
			part1="ADMIN";
		else if(typeId.equals("PRSD")) 
			part1="PROF";
		else if(typeId.equals("STSD")) 
			part1="STUD";
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT count(*) from USER_DETAILS where type_id = '" + typeId + "'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					count = result.getInt(1);
					if(count<10)
					{
						System.out.println("count"+count);
						if(part1.equals("ADMIN")) {
							userId=part1+"0"+count;
						}
						else {
							userId=part1+"00"+count;
						}
					}
					if(count<99 && count>9)
					{
						userId=part1+"0"+count;
					}
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		while(alreadyExists(userId))
		{
			count++;
			if(count<10)
			{
				System.out.println("count"+count);
				if(part1.equals("ADMIN")) {
					userId=part1+"0"+count;
				}
				else {
					userId=part1+"00"+count;
				}
			}
			if(count<99 && count>9)
			{
				userId=part1+"0"+count;
			}
		}
				
		return userId;
	}
	
	private static boolean alreadyExists(String userId) {
		boolean present = false;
		int count=0;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT count(*) FROM MCAPROJECT.user_details where user_id='"+userId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					count =result.getInt(1);
					
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		if (count!=0)
			present=true;
		return present;
	}

	public static String generateQuestionId() {

		String qstionId = null;
		String part1 = "NTS0";
		int count = 0;
		
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT count(*) from module_notes";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					count = result.getInt(1);
					qstionId = part1 + count;
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		while(alreadyExistsNotesId(qstionId))
		{
			count++;
			qstionId = part1 + count;
		}
		
		return qstionId;
	}
	private static boolean alreadyExistsNotesId(String userId) {
		boolean present = false;
		int count=0;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT count(*) FROM MCAPROJECT.module_notes where notes_id='"+userId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					count =result.getInt(1);
					
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		if (count!=0)
			present=true;
		return present;
	}
	
	public static boolean addNewUser(UserDetails userDetails) {

		int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {


System.out.println("inside");
				

			
				//adding customer
				preStmt=conCore.prepareStatement("insert into MCAPROJECT.USER_DETAILS values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				preStmt.setString(1,userDetails.getUserId());
				preStmt.setString(2,userDetails.getTypeId());
				preStmt.setString(3,userDetails.getUserName());
				preStmt.setString(4,userDetails.getTitle());
				preStmt.setString(5,userDetails.getFirstName());
				preStmt.setString(6,userDetails.getLastName());
				preStmt.setString(7,userDetails.getEmail());
				preStmt.setString(8,userDetails.getPassword());
				preStmt.setDate(9, userDetails.getDob());
				preStmt.setString(10,userDetails.getAddress());
				preStmt.setDate(11,userDetails.getRegisteredTime());
				preStmt.setString(12,userDetails.getSecretQuestion());
				preStmt.setString(13,userDetails.getSecretAnswer());
				preStmt.setString(14,userDetails.getContactNo());
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}

	public static String getModuleId(String subject, int subjectId) {
		String moduleId = new String();
		int count = 1;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT count(*) FROM MCAPROJECT.SUBJECT s where s.SUBJECT = '" + subject + "'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					count = count + result.getInt(1);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		moduleId = "S"+subjectId+"M";
		
		if(count<10)
			moduleId = moduleId + "000" +count+"";
		else if(count>9 && count<100)
			moduleId = moduleId + "00" +count+"";
		else if(count>99 && count<1000)
			moduleId = moduleId + "0" +count+"";
		else if(count>999 && count<10000)
			moduleId = moduleId +count+"";
		
		while(alreadyExistsModuleId(moduleId))
		{
			count++;
			moduleId = "S"+subjectId+"M";
			
			if(count<10)
				moduleId = moduleId + "000" +count+"";
			else if(count>9 && count<100)
				moduleId = moduleId + "00" +count+"";
			else if(count>99 && count<1000)
				moduleId = moduleId + "0" +count+"";
			else if(count>999 && count<10000)
				moduleId = moduleId +count+"";
		}
		
		return moduleId;
	}
	
	private static boolean alreadyExistsModuleId(String userId) {
		boolean present = false;
		int count=0;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT count(*) FROM MCAPROJECT.subject where module_id='"+userId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					count =result.getInt(1);
					
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		if (count!=0)
			present=true;
		return present;
	}
	
	
	public static boolean addSyllabus(Subject subject) {

		int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

		
				//adding subject
				preStmt=conCore.prepareStatement("Insert into MCAPROJECT.SUBJECT (SUBJECT_ID,MODULE_ID,SUBJECT,MODULE) values (?,?,?,?)");
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				preStmt.setInt(1,subject.getSubjectId());
				preStmt.setString(2,subject.getModuleId());
				preStmt.setString(3,subject.getSubject());
				preStmt.setString(4,subject.getModule());
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}


	public static boolean updateUser(UserDetails userDetails) {
		int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {


System.out.println("inside");
				

			
				//adding customer
				preStmt=conCore.prepareStatement("UPDATE user_details SET user_name=?, title=?, first_name=?, last_name=?, email=?, address=?, contactno=? WHERE user_id=?");

				preStmt.setString(1,userDetails.getUserName());
				preStmt.setString(2,userDetails.getTitle());
				preStmt.setString(3,userDetails.getFirstName());
				preStmt.setString(4,userDetails.getLastName());
				preStmt.setString(5,userDetails.getEmail());
				preStmt.setString(6,userDetails.getAddress());
				preStmt.setString(7,userDetails.getContactNo());
				preStmt.setString(8,userDetails.getUserId());
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}


	public static boolean updateSubject(Subject updatedSubject) {
		int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {


System.out.println("inside");
				

			
				//adding customer
				preStmt=conCore.prepareStatement("UPDATE subject SET subject_id=?, subject=?, module=? WHERE module_id=?");

				preStmt.setLong(1,updatedSubject.getSubjectId());
				preStmt.setString(2,updatedSubject.getSubject());
				preStmt.setString(3,updatedSubject.getModule());
				preStmt.setString(4,updatedSubject.getModuleId());
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}


	public static String getProfessorName(String profId) {
		String professorName = null;
		
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select user_name, title, first_name, last_name from user_details where user_id='"+profId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					professorName = result.getString(1)+" ("+result.getString(2)+" "+result.getString(3)+" "+result.getString(4)+")";
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return professorName;
	}


	public static int getSubjectId(String subjectName) {
int subjectId = 0;
		
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select unique(subject_id) from subject where subject ='"+subjectName+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					subjectId = (int) result.getLong(1);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return subjectId;
	}


	public static boolean assignFacultyToSubject(Faculty assignFaculty) {
		 int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

		
				//adding subject
				preStmt=conCore.prepareStatement("Insert into MCAPROJECT.FACULTY (PROF_ID,PROF_NAME,SUBJECT_ID) values (?,?,?)");
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				preStmt.setString(1,assignFaculty.getProfId());
				preStmt.setString(2,assignFaculty.getProfessorName());
				preStmt.setLong(3,assignFaculty.getSubjectId());
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}
	
	public static boolean updateAssignFacultyToSubject(Faculty assignFaculty) {
		 int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

		
				//adding subject
				preStmt=conCore.prepareStatement("UPDATE faculty SET subject_id=? WHERE prof_id=?");
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				preStmt.setLong(1,assignFaculty.getSubjectId());
				preStmt.setString(2,assignFaculty.getProfId());
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}


	public static boolean deleteAssignFacultyToSubject(String profId) {
		 int check=0;
			boolean status=false;
			conCore = ConnectionEstablisher.getConnection();
	try {

				
				PreparedStatement preStmt;

				if (conCore != null) {

			
					//adding subject
					preStmt=conCore.prepareStatement("DELETE FROM faculty WHERE PROF_ID=?");
					System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
					preStmt.setString(1,profId);
					check=preStmt.executeUpdate();
					
					if(check!=0){
						status=true;
						conCore.commit();
					}
					
					conCore.close();
				} 
				else {
					System.out.println("No DB Connection");
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {

				ConnectionEstablisher.closeResultSet(result);
				ConnectionEstablisher.closePreparedStatement(preStmt);
				ConnectionEstablisher.closeConnection(conCore);
			}
			
			return status;
	}


	public static String[] validateUser(UserDetails userLoginCred) {
String[] roleName = new String[3];
		String tempRole = "error";
String typeId="";
String title="";
String fName="";
String lName="";
String name="";
String userId="";
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select type_id, title, first_name, last_name, user_id from user_details where USER_NAME='"+userLoginCred.getUserName()+"' and PASSWORD='"+AESalgorithm.encrypt(userLoginCred.getPassword())+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					typeId = result.getString(1);
					title = result.getString(2);
					fName = result.getString(3);
					lName = result.getString(4);
					userId = result.getString(5);
				}
				if(typeId.equals("ADSD")) {
					tempRole = "Admin";
					name = title + " " + fName + " " +lName;
				}
				else if(typeId.equals("PRSD")) {
					tempRole = "Professor";
					name = title + " " + fName + " " +lName;
				}
				else if(typeId.equals("STSD")) {
					tempRole = "Student";
					name = title + " " + fName + " " +lName;
				}
				roleName[0] = tempRole;
				roleName[1] = name;
				roleName[2] = userId;
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return roleName;
	}

	public static boolean addNotes(ModuleNotes notes) {
		int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {


System.out.println("inside");
				

			
				//adding customer
				preStmt=conCore.prepareStatement("Insert into MCAPROJECT.MODULE_NOTES values (?,?,?,?)");
				preStmt.setString(1,notes.getNotesId());
				preStmt.setString(2,notes.getProfId());
				preStmt.setString(3,notes.getModuleId());
				preStmt.setString(4,notes.getNotesFileName());				
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}

	public static String getModuleIdFor(String subject, String module) {
		String moduleId = new String();
		
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select module_id from subject where subject = '"+subject+"' and module='"+module+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					moduleId= result.getString(1);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return moduleId;
	}
	public static String getNotesIdForModuleId(String moduleId) {
		String notesId = "";
		
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select NOTES_ID FROM MCAPROJECT.MODULE_NOTES WHERE MODULE_ID='"+moduleId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					notesId= result.getString(1);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return notesId;
	}
	
	public static boolean initiateDiscussionForum(String userId) {
		
	

		int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {


System.out.println("inside");
				

			
				//adding customer
				preStmt=conCore.prepareStatement("insert into MCAPROJECT.Discussion_Forum_Participants values(?,?)");
				preStmt.setString(1,userId);
				preStmt.setString(2,getProfessorName(userId));
				
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;	
	}

	public static boolean resetDiscussionForum() {

		int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {


System.out.println("inside");
				

			
				//adding customer
				preStmt=conCore.prepareStatement("truncate table MCAPROJECT.Discussion_Forum_Participants");
	
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;	
	}

	public static String isParticipant(String id) {
String pId = "NA";
		
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select user_id from DISCUSSION_FORUM_PARTICIPANTS where user_id='"+id+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					pId= result.getString(1);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return pId;
	}
	public static ArrayList<ArrayList<String>> getModuleNotes() {

		ArrayList<ArrayList<String>> sidebarData = new ArrayList<ArrayList<String>>();
		ArrayList<String> sidebarRow = null;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select sub.subject, sub.module, nts.notes_filename from module_notes nts inner join subject sub on sub.module_id = nts.MODULE_ID";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				while (result.next()) {
					sidebarRow = new ArrayList<String>();
					sidebarRow.add(result.getString(1));
					sidebarRow.add(result.getString(2));
					sidebarRow.add(result.getString(3));
					sidebarData.add(sidebarRow);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarData;
	}

	public static boolean addProgress(String userId, String moduleId) {
		boolean status=false;
		if(checkProgress(userId, moduleId))
		{
			status=true;
		}
		else
		{
		int check=0;
		
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {


System.out.println("inside");
				

			
				//adding customer
				preStmt=conCore.prepareStatement("insert into mcaproject.student_progress values(?,?)");
				preStmt.setString(1,userId);
				preStmt.setString(2,moduleId);
				
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
			
	}
		return status;
	}

	private static boolean checkProgress(String userId, String moduleId) {
		boolean present=false;
		
		int count=0;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select Count(*) from mcaproject.student_progress where STUDENT_ID='"+userId+"' and MODULE_ID='"+moduleId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					
					count=result.getInt(1);
									
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		if(count!=0)
			present=true;
		else
			present=false;
		return present;
	}
	public static ArrayList<ArrayList<String>> getProgressOfStudent(String userId) {

		ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
		ArrayList<String> sidebarData = new ArrayList<String>();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select sub.subject, sub.module from mcaproject.subject sub where sub.module_id in (select pro.module_id from mcaproject.student_progress pro where pro.student_id='"+userId+"')";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				while (result.next()) {
					sidebarData = new ArrayList<String>();
					sidebarData.add(result.getString(1));
					sidebarData.add(result.getString(2));
					data.add(sidebarData);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return data;
	}	
	public static ArrayList<String> fetchUserInfo(String userId) {

		ArrayList<String> sidebarRow = new ArrayList<String>();
		
		conCore = ConnectionEstablisher.getConnection();
try {
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select USER_ID,USER_NAME,TITLE,FIRST_NAME,LAST_NAME,EMAIL,CONTACTNO,ADDRESS,DOB,REGISTERED_TIME from MCAPROJECT.USER_DETAILS where user_id='"+userId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				
				if (result.next()) {
					sidebarRow = new ArrayList<String>();
					sidebarRow.add(result.getString(1));
					sidebarRow.add(result.getString(2));
					sidebarRow.add(result.getString(3));
					sidebarRow.add(result.getString(4));
					sidebarRow.add(result.getString(5));
					sidebarRow.add(result.getString(6));
					sidebarRow.add(result.getString(7));
					sidebarRow.add(result.getString(8));
					sidebarRow.add(result.getString(9));
					sidebarRow.add(result.getString(10));
					
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarRow;
	}
	public static String getNewsId() {

		String newsId = "";
		String part1="NS";
		int count=0;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT count(*) from news_feeds";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					count = result.getInt(1);
					count++;
					if(count<10)
					{
						System.out.println("count"+count);
						newsId=part1+"00"+count;
					}
					if(count<99 && count>9)
					{
						newsId=part1+"0"+count;
					}
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		while(alreadyExistsNewsId(newsId))
		{
		count++;
		if(count<10)
		{
			System.out.println("count"+count);
			newsId=part1+"00"+count;
		}
		if(count<99 && count>9)
		{
			newsId=part1+"0"+count;
		}
		}
		return newsId;
	}
	
	private static boolean alreadyExistsNewsId(String newsId) {
		boolean present = false;
		int count=0;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "SELECT count(*) FROM MCAPROJECT.news_feeds where news_id='"+newsId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				if (result.next()) {
					count =result.getInt(1);
					
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		if (count!=0)
			present=true;
		return present;
	}
	public static boolean addNews(String newsId, String userId, String news) {

		int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {


System.out.println("inside");
				

			
				//adding customer
				preStmt=conCore.prepareStatement("insert into MCAPROJECT.news_feeds values(?,?,?)");
				preStmt.setString(1,newsId);
				preStmt.setString(2,userId);
				preStmt.setString(3,news);
				
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}
	public static ArrayList<String> fetchAllNewsByUserId(String userId) {

		ArrayList<String> sidebarRow = new ArrayList<String>();
		
		conCore = ConnectionEstablisher.getConnection();
try {
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select NEWS from news_feeds where prof_id ='"+userId+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				
				while (result.next()) {
					
					sidebarRow.add(result.getString(1));
					
					
					
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return sidebarRow;
	}
	public static String fetchNewsIdFromNews(String news) {

		String newsId = "";
		
		conCore = ConnectionEstablisher.getConnection();
try {
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select NEWS_ID from news_feeds where news ='"+news+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				
				if (result.next()) {
					newsId = result.getString(1);	
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return newsId;
	}

	public static boolean updateNews(String newsId, String news) {
		int check=0;
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {


System.out.println("inside");
				

			
				//adding customer
				preStmt=conCore.prepareStatement("UPDATE news_feeds SET news=? WHERE news_id=?");

				preStmt.setString(1,news);
				preStmt.setString(2,newsId);
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				check=preStmt.executeUpdate();
				
				if(check!=0){
					status=true;
					conCore.commit();
				}
				
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}

	public static boolean deleteUser(String userId) throws SQLException {
		
		boolean status=false;
		System.out.println("Faculty Deleted : " + deleteFaculty(userId));
		System.out.println("Module Notes Deleted : " + deleteModlueNotes(userId));
		System.out.println("News Feeds Deleted : " + deleteNewsFeeds(userId));
		System.out.println("Student Progress Deleted : " + deleteStudentProgress(userId));
		Procedure.disableConstraint();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {



			
				//adding customer
				preStmt=conCore.prepareStatement("delete from  mcaproject.user_details where user_id=?");

				preStmt.setString(1,userId);
				
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				status=preStmt.execute();
				
				Procedure.enableConstraint();
				conCore.commit();
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}
	
public static boolean deleteNotes(String moduleId) throws SQLException {
		
		boolean status=false;

		System.out.println("Student Progress Deleted : " + deleteStudentProgressById(moduleId));
		Procedure.disableConstraint();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {



			
				//adding customer
				preStmt=conCore.prepareStatement("delete FROM MCAPROJECT.MODULE_NOTES WHERE MODULE_ID=?");
				
				preStmt.setString(1,moduleId);
				
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				status=preStmt.execute();
				
				Procedure.enableConstraint();
				conCore.commit();
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}
	
	
	public static boolean deleteStudentProgress(String userId) {
		
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {



			
				//adding customer
				preStmt=conCore.prepareStatement("delete from mcaproject.student_progress where student_id=?");
				
				preStmt.setString(1,userId);
				
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				status=preStmt.execute();
				System.out.println(status);
				
				conCore.commit();
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}
	public static boolean deleteFaculty(String userId) {
	
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {



			
				//adding customer
				preStmt=conCore.prepareStatement("delete from mcaproject.faculty where prof_id=?");

				preStmt.setString(1,userId);
				
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				status=preStmt.execute();
				System.out.println(status);
				
				conCore.commit();
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}
	public static boolean deleteModlueNotes(String userId) {
		 
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {



			
				//adding customer
				preStmt=conCore.prepareStatement("delete from mcaproject.module_notes where prof_id=?");

				preStmt.setString(1,userId);
				
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				status=preStmt.execute();
				
				
				conCore.commit();
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}
	public static boolean deleteNewsFeeds(String userId) {
		
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {



			
				//adding customer
				preStmt=conCore.prepareStatement("delete from mcaproject.news_feeds where prof_id=?");

				preStmt.setString(1,userId);
				
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				status=preStmt.execute();
				
				
				conCore.commit();
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}

	public static String deleteNews(String news) throws SQLException {
		String newsId = fetchNewsIdFromNews(news);
		Procedure.disableConstraint();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {



			
				//adding customer
				preStmt=conCore.prepareStatement("delete from  mcaproject.news_feeds where news=?");

				preStmt.setString(1,news);
				
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				preStmt.execute();
				
				Procedure.enableConstraint();
				conCore.commit();
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
return newsId;
	}
	public static ArrayList<ArrayList<String>> getCompleteSyllabus() {

		ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
		ArrayList<String> sidebarData = new ArrayList<String>();
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select sub.subject, sub.module from mcaproject.subject sub";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();

				while (result.next()) {
					sidebarData = new ArrayList<String>();
					sidebarData.add(result.getString(1));
					sidebarData.add(result.getString(2));
					data.add(sidebarData);
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return data;
	}

	public static String deleteModule(String module) throws SQLException {
		 
		String moduleId=fetchModuleIdFromModule(module);
		System.out.println("Module Notes Deleted : " + deleteModlueNotesById(moduleId));
		System.out.println("Student Progress Deleted : " + deleteStudentProgressById(moduleId));
		Procedure.disableConstraint();
		conCore = ConnectionEstablisher.getConnection();
try {
	
			
			PreparedStatement preStmt;

			if (conCore != null) {



			
				//adding customer
				preStmt=conCore.prepareStatement("delete from mcaproject.subject where module=?");

				preStmt.setString(1,module);
				
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				preStmt.execute();
				
				Procedure.enableConstraint();
				conCore.commit();
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return moduleId;
	}
	public static String fetchModuleIdFromModule(String module) {

		String newsId = "";
		
		conCore = ConnectionEstablisher.getConnection();
try {
			PreparedStatement preStmt;

			if (conCore != null) {

				String query = "select MODULE_ID from SUBJECT where MODULE ='"+module+"'";
				System.out.println("info "+new Date()+" Entering DB with Query::" + query);
				preStmt = conCore.prepareStatement(query);
				ResultSet result = preStmt.executeQuery();
				
				
				if (result.next()) {
					newsId = result.getString(1);	
				}
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return newsId;
	}
	
	
	
	public static boolean deleteModlueNotesById(String moduleId) {
		 
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {



			
				//adding customer
				preStmt=conCore.prepareStatement("delete from mcaproject.module_notes where module_id=?");

				preStmt.setString(1,moduleId);
				
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				status=preStmt.execute();
				
				
				conCore.commit();
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}
	public static boolean deleteStudentProgressById(String moduleId) {
		 
		boolean status=false;
		conCore = ConnectionEstablisher.getConnection();
try {

			
			PreparedStatement preStmt;

			if (conCore != null) {



			
				//adding customer
				preStmt=conCore.prepareStatement("delete from mcaproject.student_progress where module_id=?");

				preStmt.setString(1,moduleId);
				
			
				System.out.println("info "+new Date()+" Entering DB with Query::" + preStmt);
				status=preStmt.execute();
				
				
				conCore.commit();
				conCore.close();
			} 
			else {
				System.out.println("No DB Connection");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ConnectionEstablisher.closeResultSet(result);
			ConnectionEstablisher.closePreparedStatement(preStmt);
			ConnectionEstablisher.closeConnection(conCore);
		}
		
		return status;
	}
	
}
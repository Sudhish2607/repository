package sdh.gateway.pipeline;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * Participants.java
 * 
 * Version:
 * 		 v1.1, 07/16/2017, 18:01:18
 *
 * Revision:
 *		Initial revision 
 */

/**
 * This program acts as the client for the discussion forum. This class would be used by students
 * participating the discussion forum
 * 
 * @author Thazhakasseril, Sudhish Surendran
 *
 */
public class Participants {
	BufferedReader in;
	PrintWriter out;
	JFrame frame = new JFrame("Discussion Forum");
	JTextField textField = new JTextField(40);
	JTextArea messageArea = new JTextArea(8, 40);

	public Participants() {
		textField.setEditable(false);
		messageArea.setEditable(false);
		frame.getContentPane().add(textField, "North");
		frame.getContentPane().add(new JScrollPane(messageArea), "Center");
		frame.pack();
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				out.println(textField.getText());
				textField.setText("");
			}
		});
	}

	private String getName() {
		return JOptionPane.showInputDialog(frame, "Enter userName:",
				"Screen name selection", JOptionPane.PLAIN_MESSAGE);
	}

	
	/**
	 * This function helps the user to get connected to the chat server
	 *
	 * @param		serverIP		value to be encrypted
	 * @param		userID			userID for the participants
	 */
	private void run(String serverIP, String userID) throws IOException {
		System.out.println("in run");
		String serverAddress = serverIP;
		Socket socket = new Socket(serverAddress, 9001);
		in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		out = new PrintWriter(socket.getOutputStream(), true);
		while (true) {
			String line = in.readLine();
			if (line.startsWith("SUBMITNAME")) {
				System.out.println("submitname");
				out.println(getName());
			} else if (line.startsWith("NAMEACCEPTED")) {
				textField.setEditable(true);
			} else if (line.startsWith("MESSAGE")) {
				messageArea.append(line.substring(8) + "\n");
			}
		}
	}

	
	/**
	 * This function helps the admin/ professor to add participant in the discussion forum
	 *
	 * @param		serverIP		value to be encrypted
	 * @param		userID			userID for the participants
	 */
	public static void addParticipant(String serverIP, String userID)
			throws Exception {
		Participants client = new Participants();
		System.out.println(serverIP + userID);
		client.frame.setVisible(true);
		client.run(serverIP, userID);
	}
}
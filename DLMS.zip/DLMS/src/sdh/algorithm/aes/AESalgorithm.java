package sdh.algorithm.aes;

import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * AESalgorithm.java
 * 
 * Version:
 * 		 v1.1, 07/17/2017, 10:20:18
 *
 * Revision:
 *		Initial revision 
 */

/**
 * This program encrypts or decrypts the password entered by the user 
 * before saving it into database. The algorithm used for encryption
 * is AES Algorithm
 * 
 * @author Thazhakasseril, Sudhish Surendran
 *
 */
public class AESalgorithm {
	
	static Cipher cipher;											// holds cipher value

	private static final String ALGORITHM = "AES";					// holds algorithm used
	
	private static final String KEY = "sudhish_ts@26792";			// holds key to be used for encryption/ decryption

	
	/**
	 * Given the value to be encrypted, this function encodes the value
	 * using AES Algorithm.
	 *
	 * @param		value		value to be encrypted
	 * 
	 * @return					encrypted value
	 */
	public static String encrypt(String value) throws Exception {
		
		Key key = generateKey();										// holds the key value
		
		Cipher cipher = Cipher.getInstance(AESalgorithm.ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE, key);
		
		byte[] encryptedByteValue = cipher.doFinal(value.getBytes("utf-8"));
		
		// encodes the value using AES algorithm with base 64
		String encryptedValue64 = new BASE64Encoder()
				.encode(encryptedByteValue);
		
		return encryptedValue64;
	}

	
	/**
	 * Given the encrypted value to be decrypted, this function decodes the value
	 * using AES Algorithm.
	 *
	 * @param		value		encoded value to be decrypted
	 * 
	 * @return					decrypted value
	 */
	public static String decrypt(String value) throws Exception {
		
		Key key = generateKey();										// holds the key value
		
		Cipher cipher = Cipher.getInstance(AESalgorithm.ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, key);
		
		// encodes the value using AES algorithm with base 64
		byte[] decryptedValue64 = new BASE64Decoder().decodeBuffer(value);
		
		byte[] decryptedByteValue = cipher.doFinal(decryptedValue64);
		String decryptedValue = new String(decryptedByteValue, "utf-8");
		
		return decryptedValue;
	}

	
	/**
	 * This function is used to set key for AES Algorithm.
	 *
	 * @param		value		encoded value to be decrypted
	 * 
	 * @return					Key to be used for AES Algorithm
	 */
	private static Key generateKey() throws Exception {
		
		Key key = new SecretKeySpec(AESalgorithm.KEY.getBytes(),
				AESalgorithm.ALGORITHM);
		
		return key;
	}
}
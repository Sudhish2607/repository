/**
 * 
 */
package sdh.bean;

/**
 * @author sudhish
 *
 */
public class Faculty {

	private String profId;
	private String professorName;
	private int subjectId;
	public String getProfId() {
		return profId;
	}
	public void setProfId(String profId) {
		this.profId = profId;
	}
	public String getProfessorName() {
		return professorName;
	}
	public void setProfessorName(String professorName) {
		this.professorName = professorName;
	}
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	
}

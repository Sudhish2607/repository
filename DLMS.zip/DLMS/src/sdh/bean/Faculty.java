package sdh.bean;

/**
 * Faculty.java
 * 
 * Version:
 * 		 v1.1, 07/16/2017, 18:23:45
 *
 * Revision:
 *		Initial revision 
 */

/**
 * This program is used as a user defines datatype for Faculty. It consists
 * of professor ID, Professor name and Subject ID
 * 
 * @author Thazhakasseril, Sudhish Surendran
 *
 */
public class Faculty {

	private String profId;					// holds id alloted to the professor
	
	private String professorName;			// holds name of the professor
	
	private int subjectId;					// holds subject ID alloted to the professor
	
	
	/**
	 * This function is used as a getter method for variable profId
	 * 
	 * @return				ID alloted to the professor
	 */
	public String getProfId() {
		return profId;
	}
	
	
	/**
	 * This function is used as a setter method for variable profId
	 * 
	 * @param				ID alloted to the professor
	 */
	public void setProfId(String profId) {
		this.profId = profId;
	}
	
	
	/**
	 * This function is used as a getter method for variable profName
	 * 
	 * @return				Name of the professor
	 */
	public String getProfessorName() {
		return professorName;
	}
	
	
	/**
	 * This function is used as a setter method for variable profName
	 * 
	 * @param				Name of the professor
	 */
	public void setProfessorName(String professorName) {
		this.professorName = professorName;
	}
	
	
	/**
	 * This function is used as a getter method for variable subjectId
	 * 
	 * @return				subject ID alloted to the professor
	 */
	public int getSubjectId() {
		return subjectId;
	}
	
	
	/**
	 * This function is used as a setter method for variable subjectId
	 * 
	 * @param				subject ID alloted to the professor
	 */
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	
}

/**
 * 
 */
package sdh.bean;

/**
 * UserDetails.java
 * 
 * Version:
 * 		 v1.1, 07/16/2017, 15:18:40
 *
 * Revision:
 *		Initial revision 
 */

/**
 * This program is used as a user defines datatype for ModuleNotes. It consists
 * of notes ID, module ID, Professor ID and file name of notes uploaded by the professor
 * 
 * @author Thazhakasseril, Sudhish Surendran
 *
 */
public class UserDetails {

	private String userId;							// holds alloted user ID
	
	private String typeId;							// holds alloted user type ID
	
	private String userName;						// holds user name
	
	private String title;							// holds title of user
	
	private String firstName;						// holds first name of user
	
	private String lastName;						// holds last name of user
	
	private String email;							// holds email id of the user
	
	private String password;						// holds encrypted password
	
	private java.sql.Date dob;						// holds date of birth of the user
	
	private String address;							// holds address of the user
	
	private java.sql.Date registeredTime;			// holds time of registration
	
	private String secretQuestion;					// holds secret question entered by the user
	
	private String secretAnswer;					// holds secret answer entered by the user
	
	private String contactNo;						// holds contact number of the user
	
	
	/**
	 * This function is used as a getter method for variable userId
	 * 
	 * @return				ID alloted to the user
	 */
	public String getUserId() {
		return userId;
	}
	
	
	/**
	 * This function is used as a setter method for variable userId
	 * 
	 * @param				ID alloted to the user
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	/**
	 * This function is used as a getter method for variable typeId
	 * 
	 * @return				ID alloted to the user type
	 */
	public String getTypeId() {
		return typeId;
	}
	
	
	/**
	 * This function is used as a setter method for variable typeId
	 * 
	 * @param				ID alloted to the user type
	 */
	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}
	
	
	/**
	 * This function is used as a getter method for variable userName
	 * 
	 * @return				user name
	 */
	public String getUserName() {
		return userName;
	}
	
	
	/**
	 * This function is used as a getter method for variable user userName
	 * 
	 * @param				user name
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	/**
	 * This function is used as a getter method for variable user title
	 * 
	 * @return				title of the user
	 */
	public String getTitle() {
		return title;
	}
	
	
	/**
	 * This function is used as a setter method for variable user title
	 * 
	 * @param				title of the user
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	/**
	 * This function is used as a getter method for variable firstName
	 * 
	 * @return				firstName of the user
	 */
	public String getFirstName() {
		return firstName;
	}
	
	
	/**
	 * This function is used as a setter method for variable firstName
	 * 
	 * @param				firstName of the user
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	
	/**
	 * This function is used as a getter method for variable lastName
	 * 
	 * @return				lastName of the user
	 */
	public String getLastName() {
		return lastName;
	}
	
	
	/**
	 * This function is used as a setter method for variable lastName
	 * 
	 * @param				lastName of the user
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	/**
	 * This function is used as a getter method for variable email
	 * 
	 * @return				email of the user
	 */
	public String getEmail() {
		return email;
	}
	
	
	/**
	 * This function is used as a setter method for variable email
	 * 
	 * @param				email of the user
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	/**
	 * This function is used as a getter method for variable password
	 * 
	 * @return				encrypted password of the user
	 */
	public String getPassword() {
		return password;
	}
	
	
	/**
	 * This function is used as a setter method for variable password
	 * 
	 * @param				encrypted password of the user
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	/**
	 * This function is used as a getter method for variable dob
	 * 
	 * @return				dob of the user
	 */
	public java.sql.Date getDob() {
		return dob;
	}
	
	
	/**
	 * This function is used as a setter method for variable dob
	 * 
	 * @param				dob of the user
	 */
	public void setDob(java.sql.Date dob) {
		this.dob = dob;
	}
	
	
	/**
	 * This function is used as a getter method for variable address
	 * 
	 * @return				address of the user
	 */
	public String getAddress() {
		return address;
	}
	
	
	/**
	 * This function is used as a setter method for variable address
	 * 
	 * @param				address of the user
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	/**
	 * This function is used as a getter method for variable registeredTime
	 * 
	 * @return				registered time of the user
	 */
	public java.sql.Date getRegisteredTime() {
		return registeredTime;
	}
	
	
	/**
	 * This function is used as a setter method for variable registeredTime
	 * 
	 * @param				registered time of the user
	 */
	public void setRegisteredTime(java.sql.Date registeredTime) {
		this.registeredTime = registeredTime;
	}
	
	
	/**
	 * This function is used as a getter method for variable secret question
	 * 
	 * @return				secret question entered by the user
	 */
	public String getSecretQuestion() {
		return secretQuestion;
	}
	
	
	/**
	 * This function is used as a setter method for variable secret question
	 * 
	 * @param				secret question entered by the user
	 */
	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}
	
	
	/**
	 * This function is used as a getter method for variable secret answer
	 * 
	 * @return				secret answer entered by the user
	 */
	public String getSecretAnswer() {
		return secretAnswer;
	}
	
	
	/**
	 * This function is used as a setter method for variable secret answer
	 * 
	 * @param				secret answer entered by the user
	 */
	public void setSecretAnswer(String secretAnswer) {
		this.secretAnswer = secretAnswer;
	}
	
	
	/**
	 * This function is used as a getter method for variable contactNo
	 * 
	 * @return				contactNo of the user
	 */
	public String getContactNo() {
		return contactNo;
	}
	
	
	/**
	 * This function is used as a setter method for variable contactNo
	 * 
	 * @param				contactNo of the user
	 */
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
	

}

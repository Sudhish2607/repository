package sdh.bean;

/**
 * ModuleNotes.java
 * 
 * Version:
 * 		 v1.1, 07/16/2017, 15:18:40
 *
 * Revision:
 *		Initial revision 
 */

/**
 * This program is used as a user defines datatype for ModuleNotes. It consists
 * of notes ID, module ID, Professor ID and file name of notes uploaded by the professor
 * 
 * @author Thazhakasseril, Sudhish Surendran
 *
 */
public class ModuleNotes {

	private String notesId;					// holds id alloted to the notes
	
	private String moduleId;				// holds id alloted to the module
	
	private String profId;					// holds id alloted to the professor
	
	private String notesFileName;			// holds name of the file uploaded by the professor
	
	
	/**
	 * This function is used as a getter method for variable notesId
	 * 
	 * @return				ID alloted to the notes
	 */
	public String getNotesId() {
		return notesId;
	}
	
	
	/**
	 * This function is used as a setter method for variable notesId
	 * 
	 * @param				ID alloted to the notes
	 */
	public void setNotesId(String questionId) {
		this.notesId = questionId;
	}
	
	
	/**
	 * This function is used as a getter method for variable moduleId
	 * 
	 * @return				ID alloted to the module
	 */
	public String getModuleId() {
		return moduleId;
	}
	
	
	/**
	 * This function is used as a setter method for variable moduleId
	 * 
	 * @param				ID alloted to the module
	 */
	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}
	
	
	/**
	 * This function is used as a getter method for variable profId
	 * 
	 * @return				ID alloted to the professor
	 */
	public String getProfId() {
		return profId;
	}
	
	
	/**
	 * This function is used as a setter method for variable profId
	 * 
	 * @param				ID alloted to the professor
	 */
	public void setProfId(String profId) {
		this.profId = profId;
	}
	
	
	/**
	 * This function is used as a getter method for variable notesFileName
	 * 
	 * @return				name file uploaded by professor
	 */
	public String getNotesFileName() {
		return notesFileName;
	}
	
	
	/**
	 * This function is used as a setter method for variable notesFileName
	 * 
	 * @param				name file uploaded by professor
	 */
	public void setNotesFileName(String notesFileName) {
		this.notesFileName = notesFileName;
	}
}

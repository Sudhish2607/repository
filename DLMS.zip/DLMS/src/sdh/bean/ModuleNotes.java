/**
 * 
 */
package sdh.bean;

/**
 * @author sudhish
 *
 */
public class ModuleNotes {

	private String notesId;
	private String moduleId;
	private String profId;
	private String notesFileName;
	public String getNotesId() {
		return notesId;
	}
	public void setNotesId(String questionId) {
		this.notesId = questionId;
	}
	public String getModuleId() {
		return moduleId;
	}
	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}
	public String getProfId() {
		return profId;
	}
	public void setProfId(String profId) {
		this.profId = profId;
	}
	public String getNotesFileName() {
		return notesFileName;
	}
	public void setNotesFileName(String notesFileName) {
		this.notesFileName = notesFileName;
	}
}

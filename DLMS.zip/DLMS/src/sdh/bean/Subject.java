package sdh.bean;

/**
 * @author sudhish
 *
 */
public class Subject {

	private int subjectId;
	private String moduleId;
	private String Subject;
	private String Module;
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	public String getModuleId() {
		return moduleId;
	}
	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}
	public String getSubject() {
		return Subject;
	}
	public void setSubject(String subject) {
		Subject = subject;
	}
	public String getModule() {
		return Module;
	}
	public void setModule(String module) {
		Module = module;
	}	
}

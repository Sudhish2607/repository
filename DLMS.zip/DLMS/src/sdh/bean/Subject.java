package sdh.bean;

/**
 * Subject.java
 * 
 * Version:
 * 		 v1.1, 07/16/2017, 15:18:40
 *
 * Revision:
 *		Initial revision 
 */

/**
 * This program is used as a user defines datatype for ModuleNotes. It consists
 * of notes ID, module ID, Professor ID and file name of notes uploaded by the professor
 * 
 * @author Thazhakasseril, Sudhish Surendran
 *
 */
public class Subject {

	private int subjectId;						// holds id alloted to the subject
	
	private String moduleId;					// holds id alloted to the module
	
	private String Subject;						// holds name of the Subject
	
	private String Module;						// holds name of the module
	
	
	/**
	 * This function is used as a getter method for variable subjectId
	 * 
	 * @return				ID alloted to the subject
	 */
	public int getSubjectId() {
		return subjectId;
	}
	
	
	/**
	 * This function is used as a setter method for variable subjectId
	 * 
	 * @param				ID alloted to the subject
	 */
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	
	
	/**
	 * This function is used as a getter method for variable moduleId
	 * 
	 * @return				ID alloted to the module
	 */
	public String getModuleId() {
		return moduleId;
	}
	
	
	/**
	 * This function is used as a setter method for variable moduleId
	 * 
	 * @param				ID alloted to the module
	 */
	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}
	
	
	/**
	 * This function is used as a getter method for variable subject
	 * 
	 * @return				name of the subject
	 */
	public String getSubject() {
		return Subject;
	}
	
	
	/**
	 * This function is used as a setter method for variable subject
	 * 
	 * @param				name of the subject
	 */
	public void setSubject(String subject) {
		Subject = subject;
	}
	
	
	/**
	 * This function is used as a getter method for variable module
	 * 
	 * @return				name of the module
	 */
	public String getModule() {
		return Module;
	}
	
	
	/**
	 * This function is used as a setter method for variable module
	 * 
	 * @param				name of the module
	 */
	public void setModule(String module) {
		Module = module;
	}	
}

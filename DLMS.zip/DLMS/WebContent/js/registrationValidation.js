/*Validation for Password*/
var password1 = document.getElementById('password1');
var password2 = document.getElementById('password2');
var checkPasswordValidity = function() {
	if (password1.value != password2.value) {
		password1.setCustomValidity('Passwords must match.');
	} else {
		password1.setCustomValidity('');
	}
};
password1.addEventListener('change', checkPasswordValidity, false);
password2.addEventListener('change', checkPasswordValidity, false);

var form = document.getElementById('regForm');
form.addEventListener('submit', function() {
	checkPasswordValidity();
	if (!this.checkValidity()) {
		event.preventDefault();
		//Implement you own means of displaying error messages to the user here.
		password1.focus();
	}
}, false);

/*validatin for address*/
var address = document.getElementById('address');
var checkAddressValidity = function() {
	if (address.value == 'Address') {
		address.setCustomValidity('Please enter your address');
	} else {
		address.setCustomValidity('');
	}
};
address.addEventListener('change', checkAddressValidity, false);
var form = document.getElementById('regForm');
form.addEventListener('submit', function() {
	checkAddressValidity();
	if (!this.checkValidity()) {
		event.preventDefault();
		//Implement you own means of displaying error messages to the user here.
		address.focus();
	}
}, false);

/*validation for contactNo*/
var contactNo = document.getElementById('contactNo');
var checkContactNoValidity = function() {
	if (contactNo.value.length != 10) {
		contactNo.setCustomValidity('Please enter 10 digit mobile number');
	} else {
		contactNo.setCustomValidity('');
	}
};
contactNo.addEventListener('change', checkContactNoValidity, false);
var form = document.getElementById('regForm');
form.addEventListener('submit', function() {
	checkContactNoValidity();
	if (!this.checkValidity()) {
		event.preventDefault();
		//Implement you own means of displaying error messages to the user here.
		contactNo.focus();
	}
}, false);